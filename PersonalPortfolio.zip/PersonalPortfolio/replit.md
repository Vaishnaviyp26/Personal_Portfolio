# Personal Portfolio Website - Vaishnavi Y.P

## Overview

This is a full-stack personal portfolio website for Vaishnavi Y.P built with React on the frontend and Express.js on the backend. The application showcases projects, skills, and provides a contact form. It uses modern web technologies including TypeScript, TailwindCSS, and shadcn/ui components for a polished, responsive design. The portfolio is ready for deployment and includes comprehensive documentation.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: TailwindCSS with custom CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Style**: RESTful API endpoints
- **Session Management**: Express sessions with PostgreSQL storage

## Key Components

### Database Schema
- **users**: User authentication and profiles
- **projects**: Project showcase with technologies, URLs, and featured status
- **skills**: Technical skills categorized by type (frontend, backend, tools)
- **contactMessages**: Contact form submissions
- **portfolioInfo**: Personal information and social links

### API Endpoints
- `GET /api/portfolio` - Portfolio information
- `GET /api/projects` - All projects
- `GET /api/projects/featured` - Featured projects only
- `GET /api/skills` - All skills
- `GET /api/skills/:category` - Skills by category
- `POST /api/contact` - Contact form submission

### Frontend Sections
- **Hero Section**: Introduction and call-to-action
- **About Section**: Personal information and resume download
- **Skills Section**: Technical skills organized by category
- **Projects Section**: Featured project showcases
- **Contact Section**: Contact form and social links
- **Navigation**: Smooth scrolling navigation with mobile menu

## Data Flow

1. **Initial Load**: React app queries portfolio info, projects, and skills from API
2. **User Interaction**: Form submissions and navigation handled client-side
3. **Server Communication**: TanStack Query manages API calls with caching and error handling
4. **Database Operations**: Drizzle ORM handles database queries and migrations

## External Dependencies

### Frontend Dependencies
- **UI Components**: Radix UI primitives for accessibility
- **Animations**: Lucide React icons
- **Form Validation**: Zod schemas for type-safe validation
- **Date Handling**: date-fns for date formatting
- **Carousel**: Embla Carousel for image galleries

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Store**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution

## Deployment Strategy

### Build Process
- Frontend: Vite builds optimized static assets to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Database: Drizzle migrations applied via `db:push` command

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment mode (development/production)

### Production Setup
1. Build frontend and backend: `npm run build`
2. Run database migrations: `npm run db:push`
3. Start production server: `npm start`

### Development Setup
1. Install dependencies: `npm install`
2. Set up database and environment variables
3. Run development server: `npm run dev`

## User Preferences

- Preferred communication style: Simple, everyday language
- Portfolio owner: Vaishnavi Y.P (Full Stack Developer from Bangalore, India)
- GitHub username: vaishnaviyp
- Email: vaishnavi.yp@email.com

## Recent Changes

- July 08, 2025: Initial portfolio setup with complete sections
- July 08, 2025: Updated portfolio owner to Vaishnavi Y.P
- July 08, 2025: Fixed TypeScript LSP errors in storage layer
- July 08, 2025: Added comprehensive README.md with installation and deployment instructions
- July 08, 2025: Updated all GitHub URLs and personal information

## Changelog

- July 08, 2025: Complete personal portfolio website with Hero, About, Skills, Projects, and Contact sections
- July 08, 2025: Responsive design with smooth scrolling navigation and mobile menu
- July 08, 2025: Contact form with validation and social media integration
- July 08, 2025: Resume download functionality
- July 08, 2025: Ready for deployment on GitHub Pages, Netlify, or Vercel