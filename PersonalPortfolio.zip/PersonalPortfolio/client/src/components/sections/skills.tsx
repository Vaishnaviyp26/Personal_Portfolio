import { useQuery } from "@tanstack/react-query";
import { Code, Server, Settings } from "lucide-react";
import { Skill } from "@shared/schema";
import SkillBadge from "@/components/ui/skill-badge";

export default function SkillsSection() {
  const { data: skills } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });

  const frontendSkills = skills?.filter(skill => skill.category === "frontend") || [];
  const backendSkills = skills?.filter(skill => skill.category === "backend") || [];
  const toolsSkills = skills?.filter(skill => skill.category === "tools") || [];

  const skillCategories = [
    {
      title: "Frontend",
      icon: Code,
      skills: frontendSkills,
      bgColor: "bg-primary",
    },
    {
      title: "Backend",
      icon: Server,
      skills: backendSkills,
      bgColor: "bg-accent",
    },
    {
      title: "Tools & Others",
      icon: Settings,
      skills: toolsSkills,
      bgColor: "bg-secondary",
    },
  ];

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-secondary mb-4">Skills & Technologies</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Here are the technologies and tools I work with to bring ideas to life
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const IconComponent = category.icon;
              return (
                <div key={index} className="bg-slate-50 p-8 rounded-xl">
                  <div className="text-center mb-6">
                    <div className={`w-16 h-16 ${category.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className="text-white" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold text-secondary">{category.title}</h3>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {category.skills.map((skill) => (
                      <SkillBadge key={skill.id} skill={skill} />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
