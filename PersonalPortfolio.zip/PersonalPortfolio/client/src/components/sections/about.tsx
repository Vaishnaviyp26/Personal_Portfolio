import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { PortfolioInfo } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function AboutSection() {
  const { toast } = useToast();
  const { data: portfolioInfo } = useQuery<PortfolioInfo>({
    queryKey: ["/api/portfolio"],
  });

  const handleDownloadResume = async () => {
    try {
      const response = await fetch("/api/resume");
      if (response.ok) {
        const data = await response.json();
        // Create a link element and trigger download
        const link = document.createElement('a');
        link.href = data.url;
        link.download = `${portfolioInfo?.name?.replace(/\s+/g, '_')}_Resume.pdf` || 'Resume.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast({
          title: "Resume Downloaded",
          description: "Resume has been downloaded successfully.",
        });
      } else {
        throw new Error("Failed to download resume");
      }
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download resume. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <section id="about" className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-secondary mb-4">About Me</h2>
            <div className="w-20 h-1 bg-primary mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg leading-relaxed">
                I'm a passionate full stack developer with over 3 years of experience building modern web applications. 
                I love turning complex problems into simple, beautiful solutions that users enjoy interacting with.
              </p>
              
              <p className="text-lg leading-relaxed">
                My journey in web development started during my Computer Science studies, where I discovered my love for both 
                the technical challenges of backend development and the creative aspects of frontend design. This unique blend 
                allows me to build end-to-end solutions that are both functional and visually appealing.
              </p>
              
              <p className="text-lg leading-relaxed">
                When I'm not coding, you can find me exploring new technologies, contributing to open-source projects, 
                or enjoying a good cup of coffee while reading about the latest industry trends.
              </p>
              
              <div className="pt-6">
                <button
                  onClick={handleDownloadResume}
                  className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
                >
                  <Download size={20} />
                  Download Resume
                </button>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="rounded-xl overflow-hidden shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                  alt="Modern development workspace"
                  className="w-full h-auto"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="text-3xl font-bold text-primary mb-2">25+</div>
                  <div className="text-sm text-slate-600">Projects Completed</div>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="text-3xl font-bold text-primary mb-2">3+</div>
                  <div className="text-sm text-slate-600">Years Experience</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
