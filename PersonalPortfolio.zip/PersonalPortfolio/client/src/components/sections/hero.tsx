import { useQuery } from "@tanstack/react-query";
import { ChevronDown } from "lucide-react";
import { PortfolioInfo } from "@shared/schema";

export default function HeroSection() {
  const { data: portfolioInfo } = useQuery<PortfolioInfo>({
    queryKey: ["/api/portfolio"],
  });

  const handleScrollToAbout = () => {
    const element = document.querySelector("#about");
    if (element) {
      const navHeight = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleScrollToProjects = () => {
    const element = document.querySelector("#projects");
    if (element) {
      const navHeight = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleScrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      const navHeight = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="min-h-screen gradient-bg flex items-center justify-center text-white">
      <div className="container mx-auto px-4 text-center">
        <div className="animate-fade-in">
          <div className="w-40 h-40 mx-auto mb-8 rounded-full overflow-hidden border-4 border-white shadow-2xl">
            <img 
              src={portfolioInfo?.profileImage || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"}
              alt={`${portfolioInfo?.name} - Professional Headshot`}
              className="w-full h-full object-cover"
            />
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-slide-up">
            Hi, I'm {portfolioInfo?.name?.split(' ')[0] || 'Alex'}
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 animate-slide-up opacity-90">
            {portfolioInfo?.title || 'Full Stack Developer'} {portfolioInfo?.description ? `passionate about ${portfolioInfo.description}` : 'passionate about creating beautiful, functional web experiences'}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <button
              onClick={handleScrollToProjects}
              className="bg-white text-primary px-8 py-3 rounded-full font-semibold hover:bg-slate-100 transition-all duration-300 shadow-lg"
            >
              View My Work
            </button>
            <button
              onClick={handleScrollToContact}
              className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-primary transition-all duration-300"
            >
              Get In Touch
            </button>
          </div>
          
          <div className="mt-12 animate-float">
            <button
              onClick={handleScrollToAbout}
              className="text-white hover:text-slate-200 transition-colors"
            >
              <ChevronDown size={32} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
