import { useQuery } from "@tanstack/react-query";
import { Linkedin, Github, Twitter, Instagram } from "lucide-react";
import { PortfolioInfo } from "@shared/schema";

export default function Footer() {
  const { data: portfolioInfo } = useQuery<PortfolioInfo>({
    queryKey: ["/api/portfolio"],
  });

  const socialLinks = [
    {
      icon: Linkedin,
      href: portfolioInfo?.linkedinUrl || "#",
      label: "LinkedIn"
    },
    {
      icon: Github,
      href: portfolioInfo?.githubUrl || "#",
      label: "GitHub"
    },
    {
      icon: Twitter,
      href: portfolioInfo?.twitterUrl || "#",
      label: "Twitter"
    },
    {
      icon: Instagram,
      href: portfolioInfo?.instagramUrl || "#",
      label: "Instagram"
    },
  ];

  return (
    <footer className="bg-secondary text-white py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8">
            <h3 className="text-2xl font-bold mb-4">{portfolioInfo?.name || "Alex Johnson"}</h3>
            <p className="text-slate-300 mb-6">
              {portfolioInfo?.title || "Full Stack Developer"} passionate about creating exceptional digital experiences
            </p>
            
            <div className="flex justify-center gap-6">
              {socialLinks.map((link, index) => {
                const IconComponent = link.icon;
                return (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-primary transition-colors"
                    aria-label={link.label}
                  >
                    <IconComponent size={24} />
                  </a>
                );
              })}
            </div>
          </div>
          
          <div className="border-t border-slate-600 pt-8">
            <p className="text-slate-400">
              &copy; 2024 {portfolioInfo?.name || "Alex Johnson"}. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
