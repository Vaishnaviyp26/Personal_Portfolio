import { useQuery } from "@tanstack/react-query";
import { Github } from "lucide-react";
import { Project } from "@shared/schema";
import ProjectCard from "@/components/ui/project-card";

export default function ProjectsSection() {
  const { data: projects } = useQuery<Project[]>({
    queryKey: ["/api/projects/featured"],
  });

  const handleViewAllProjects = () => {
    // Open GitHub profile in a new tab
    window.open("https://github.com/vaishnaviyp", "_blank");
  };

  return (
    <section id="projects" className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-secondary mb-4">Featured Projects</h2>
            <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Here are some of my recent projects that showcase my skills and experience
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {projects?.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <button
              onClick={handleViewAllProjects}
              className="bg-primary text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
            >
              <Github size={20} />
              View All Projects on GitHub
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
