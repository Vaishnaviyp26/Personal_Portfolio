import { Eye, Github } from "lucide-react";
import { Project } from "@shared/schema";

interface ProjectCardProps {
  project: Project;
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const handleViewLive = () => {
    if (project.liveUrl) {
      window.open(project.liveUrl, "_blank");
    }
  };

  const handleViewCode = () => {
    if (project.githubUrl) {
      window.open(project.githubUrl, "_blank");
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden card-hover project-card">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover"
        />
        <div className="project-overlay absolute inset-0 flex items-center justify-center">
          <div className="flex gap-4">
            {project.liveUrl && (
              <button
                onClick={handleViewLive}
                className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Eye size={16} />
                View Live
              </button>
            )}
            {project.githubUrl && (
              <button
                onClick={handleViewCode}
                className="bg-secondary text-white px-4 py-2 rounded-lg hover:bg-slate-600 transition-colors flex items-center gap-2"
              >
                <Github size={16} />
                View Code
              </button>
            )}
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-secondary mb-2">{project.title}</h3>
        <p className="text-slate-600 mb-4">{project.description}</p>
        
        <div className="flex flex-wrap gap-2">
          {project.technologies.map((tech, index) => (
            <span 
              key={index}
              className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-sm"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
