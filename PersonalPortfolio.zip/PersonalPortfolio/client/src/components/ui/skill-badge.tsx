import { Skill } from "@shared/schema";

interface SkillBadgeProps {
  skill: Skill;
}

export default function SkillBadge({ skill }: SkillBadgeProps) {
  return (
    <span className="skill-badge bg-white px-3 py-1 rounded-full text-sm font-medium text-slate-700 border border-slate-200 cursor-default">
      {skill.name}
    </span>
  );
}
