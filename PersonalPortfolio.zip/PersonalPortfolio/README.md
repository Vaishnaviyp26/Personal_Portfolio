# Personal Portfolio Website - Vaishnavi Y.P

A modern, responsive personal portfolio website built with React, Express.js, and TypeScript. This portfolio showcases skills, projects, and professional information with a clean, professional design.

![Portfolio Preview](https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400)

## ✨ Features

- **Responsive Design** - Optimized for all device sizes (desktop, tablet, mobile)
- **Modern UI/UX** - Clean, professional design with smooth animations
- **Interactive Sections**:
  - Hero section with professional introduction
  - About section with personal story
  - Skills organized by categories (Frontend, Backend, Tools)
  - Featured projects showcase with live demos
  - Contact form with social media integration
- **Resume Download** - Direct download functionality
- **Smooth Navigation** - Scroll-to-section navigation
- **Contact Form** - Functional contact form with validation
- **Social Media Links** - Easy access to professional profiles

## 🚀 Technologies Used

### Frontend
- **React 18** - Modern JavaScript library for building user interfaces
- **TypeScript** - Type-safe JavaScript development
- **TailwindCSS** - Utility-first CSS framework
- **Vite** - Fast build tool and development server
- **shadcn/ui** - High-quality, accessible UI components
- **TanStack Query** - Data fetching and state management
- **React Hook Form** - Forms with easy validation
- **Zod** - TypeScript-first schema validation

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **TypeScript** - Type-safe server development
- **Drizzle ORM** - Type-safe database operations

### Development Tools
- **ESBuild** - Fast JavaScript bundler
- **Wouter** - Lightweight routing
- **Lucide React** - Beautiful icons

## 📋 Prerequisites

Before running this project, make sure you have the following installed:

- **Node.js** (v18 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js) or **yarn**

## 🛠️ Installation & Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/vaishnaviyp/portfolio-website.git
   cd portfolio-website
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:5000` to view the portfolio

## 📁 Project Structure

```
portfolio-website/
├── client/                 # Frontend React application
│   ├── public/            # Static assets
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   │   ├── sections/  # Page sections (Hero, About, etc.)
│   │   │   └── ui/        # UI components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utilities and configurations
│   │   └── pages/         # Page components
├── server/                # Backend Express application
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Data storage layer
│   └── vite.ts           # Vite integration
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schemas and types
└── README.md            # Project documentation
```

## 🎯 Available Scripts

- **`npm run dev`** - Start development server (frontend + backend)
- **`npm run build`** - Build for production
- **`npm start`** - Start production server
- **`npm run db:push`** - Apply database migrations

## 🎨 Customization

### Personal Information
Update your personal details in `server/storage.ts`:
```typescript
this.portfolioInfo = {
  name: "Your Name",
  title: "Your Title",
  email: "your.email@example.com",
  // ... other fields
};
```

### Projects
Add or modify projects in the `sampleProjects` array in `server/storage.ts`:
```typescript
{
  title: "Project Name",
  description: "Project description",
  technologies: ["React", "Node.js"],
  liveUrl: "https://project-demo.com",
  githubUrl: "https://github.com/username/project"
}
```

### Skills
Update skills in the `sampleSkills` array in `server/storage.ts`:
```typescript
{ name: "React", category: "frontend", level: 5, order: 1 }
```

### Styling
- **Colors**: Modify CSS variables in `client/src/index.css`
- **Components**: Update component styles using TailwindCSS classes
- **Layout**: Adjust section layouts in `client/src/components/sections/`

## 📱 Responsive Design

The portfolio is fully responsive and includes:
- **Mobile-first approach** with progressive enhancement
- **Flexible grid layouts** that adapt to screen sizes
- **Touch-friendly navigation** for mobile devices
- **Optimized images** with proper aspect ratios

## 🌐 Deployment

### Option 1: Netlify (Recommended)
1. Build the project: `npm run build`
2. Deploy the `dist` folder to Netlify
3. Configure environment variables if needed

### Option 2: Vercel
1. Connect your GitHub repository to Vercel
2. Configure build settings:
   - Build Command: `npm run build`
   - Output Directory: `dist`

### Option 3: GitHub Pages
1. Install GitHub Pages package: `npm install --save-dev gh-pages`
2. Add deploy script to `package.json`:
   ```json
   "scripts": {
     "deploy": "npm run build && gh-pages -d dist"
   }
   ```
3. Run: `npm run deploy`

## 📧 Contact Form

The contact form includes:
- **Client-side validation** using Zod schemas
- **Form state management** with React Hook Form
- **Success/error notifications** with toast messages
- **Responsive design** for all devices

## 🔧 Technical Features

- **Type Safety** - Full TypeScript implementation
- **Performance** - Optimized with Vite and modern React patterns
- **Accessibility** - ARIA labels and semantic HTML
- **SEO Ready** - Proper meta tags and structure
- **Modern CSS** - CSS Grid, Flexbox, and custom properties
- **Smooth Animations** - CSS transitions and keyframe animations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m "Add feature"`
4. Push to branch: `git push origin feature-name`
5. Submit a pull request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 💬 Support

If you have any questions or issues:
- Create an issue on GitHub
- Contact: vaishnavi.yp@email.com
- LinkedIn: [Vaishnavi Y.P](https://linkedin.com/in/vaishnaviyp)

---

**Built with ❤️ by Vaishnavi Y.P**

*This portfolio demonstrates modern web development practices and serves as a template for creating professional portfolio websites.*