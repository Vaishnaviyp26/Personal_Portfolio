import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get portfolio info
  app.get("/api/portfolio", async (req, res) => {
    try {
      const portfolioInfo = await storage.getPortfolioInfo();
      res.json(portfolioInfo);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch portfolio info" });
    }
  });

  // Get all projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Get featured projects
  app.get("/api/projects/featured", async (req, res) => {
    try {
      const projects = await storage.getFeaturedProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured projects" });
    }
  });

  // Get skills
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getSkills();
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  // Get skills by category
  app.get("/api/skills/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const skills = await storage.getSkillsByCategory(category);
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch skills by category" });
    }
  });

  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.json({ message: "Message sent successfully", id: message.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid form data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  // Download resume
  app.get("/api/resume", async (req, res) => {
    try {
      const portfolioInfo = await storage.getPortfolioInfo();
      if (!portfolioInfo?.resumeUrl) {
        return res.status(404).json({ message: "Resume not found" });
      }
      
      // In a real application, this would serve the actual file
      // For now, we'll return the URL
      res.json({ url: portfolioInfo.resumeUrl });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resume" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
