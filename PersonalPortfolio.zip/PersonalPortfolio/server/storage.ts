import { 
  users, 
  projects, 
  skills, 
  contactMessages, 
  portfolioInfo,
  type User, 
  type InsertUser,
  type Project,
  type InsertProject,
  type Skill,
  type InsertSkill,
  type ContactMessage,
  type InsertContactMessage,
  type PortfolioInfo,
  type InsertPortfolioInfo
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Project methods
  getProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  
  // Skill methods
  getSkills(): Promise<Skill[]>;
  getSkillsByCategory(category: string): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  
  // Contact message methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  
  // Portfolio info methods
  getPortfolioInfo(): Promise<PortfolioInfo | undefined>;
  updatePortfolioInfo(info: InsertPortfolioInfo): Promise<PortfolioInfo>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private skills: Map<number, Skill>;
  private contactMessages: Map<number, ContactMessage>;
  private portfolioInfo: PortfolioInfo | undefined;
  
  private currentUserId: number;
  private currentProjectId: number;
  private currentSkillId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.skills = new Map();
    this.contactMessages = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentSkillId = 1;
    this.currentMessageId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize portfolio info
    this.portfolioInfo = {
      id: 1,
      name: "Vaishnavi Y.P",
      title: "Full Stack Developer",
      description: "Passionate about creating beautiful, functional web experiences",
      email: "vaishnavi.yp@email.com",
      phone: "+91 98765 43210",
      location: "Bangalore, India",
      linkedinUrl: "https://linkedin.com/in/vaishnaviyp",
      githubUrl: "https://github.com/vaishnaviyp",
      twitterUrl: "https://twitter.com/vaishnaviyp",
      instagramUrl: "https://instagram.com/vaishnaviyp",
      profileImage: "https://images.unsplash.com/photo-1494790108755-2616b612b002?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400",
      resumeUrl: "/resume.pdf"
    };

    // Initialize sample projects
    const sampleProjects: InsertProject[] = [
      {
        title: "E-commerce Platform",
        description: "A full-stack e-commerce solution with user authentication, product management, shopping cart, and payment integration using React and Node.js.",
        image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        technologies: ["React", "Node.js", "MongoDB", "Stripe"],
        liveUrl: "https://ecommerce-demo.com",
        githubUrl: "https://github.com/vaishnaviyp/ecommerce",
        featured: true,
        order: 1
      },
      {
        title: "Task Management App",
        description: "A collaborative task management application with real-time updates, drag-and-drop functionality, and team collaboration features.",
        image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        technologies: ["Vue.js", "Express.js", "Socket.io", "PostgreSQL"],
        liveUrl: "https://taskmanager-demo.com",
        githubUrl: "https://github.com/vaishnaviyp/taskmanager",
        featured: true,
        order: 2
      },
      {
        title: "Weather Dashboard",
        description: "A responsive weather application with location-based forecasts, interactive maps, and beautiful data visualizations.",
        image: "https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        technologies: ["React", "Chart.js", "API Integration", "PWA"],
        liveUrl: "https://weather-dashboard-demo.com",
        githubUrl: "https://github.com/vaishnaviyp/weather-dashboard",
        featured: true,
        order: 3
      },
      {
        title: "Social Media Platform",
        description: "A full-featured social media platform with user profiles, posts, comments, likes, and real-time messaging capabilities.",
        image: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        technologies: ["React", "Django", "WebSocket", "Redis"],
        liveUrl: "https://social-platform-demo.com",
        githubUrl: "https://github.com/vaishnaviyp/social-platform",
        featured: true,
        order: 4
      }
    ];

    sampleProjects.forEach(project => {
      this.createProject(project);
    });

    // Initialize sample skills
    const sampleSkills: InsertSkill[] = [
      // Frontend
      { name: "React", category: "frontend", level: 5, order: 1 },
      { name: "Vue.js", category: "frontend", level: 4, order: 2 },
      { name: "JavaScript", category: "frontend", level: 5, order: 3 },
      { name: "TypeScript", category: "frontend", level: 4, order: 4 },
      { name: "HTML5", category: "frontend", level: 5, order: 5 },
      { name: "CSS3", category: "frontend", level: 5, order: 6 },
      { name: "Tailwind CSS", category: "frontend", level: 4, order: 7 },
      { name: "Sass", category: "frontend", level: 4, order: 8 },
      
      // Backend
      { name: "Node.js", category: "backend", level: 5, order: 1 },
      { name: "Express.js", category: "backend", level: 5, order: 2 },
      { name: "Python", category: "backend", level: 4, order: 3 },
      { name: "Django", category: "backend", level: 4, order: 4 },
      { name: "PostgreSQL", category: "backend", level: 4, order: 5 },
      { name: "MongoDB", category: "backend", level: 4, order: 6 },
      { name: "REST APIs", category: "backend", level: 5, order: 7 },
      { name: "GraphQL", category: "backend", level: 3, order: 8 },
      
      // Tools
      { name: "Git", category: "tools", level: 5, order: 1 },
      { name: "Docker", category: "tools", level: 4, order: 2 },
      { name: "AWS", category: "tools", level: 4, order: 3 },
      { name: "Netlify", category: "tools", level: 4, order: 4 },
      { name: "Figma", category: "tools", level: 4, order: 5 },
      { name: "Jest", category: "tools", level: 4, order: 6 },
      { name: "Webpack", category: "tools", level: 3, order: 7 },
      { name: "Agile", category: "tools", level: 4, order: 8 }
    ];

    sampleSkills.forEach(skill => {
      this.createSkill(skill);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return Array.from(this.projects.values())
      .filter(project => project.featured)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const project: Project = { 
      ...insertProject, 
      id,
      order: insertProject.order ?? 0,
      liveUrl: insertProject.liveUrl ?? null,
      githubUrl: insertProject.githubUrl ?? null,
      featured: insertProject.featured ?? false
    };
    this.projects.set(id, project);
    return project;
  }

  async getSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values()).sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  async getSkillsByCategory(category: string): Promise<Skill[]> {
    return Array.from(this.skills.values())
      .filter(skill => skill.category === category)
      .sort((a, b) => (a.order || 0) - (b.order || 0));
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = this.currentSkillId++;
    const skill: Skill = { 
      ...insertSkill, 
      id,
      order: insertSkill.order ?? 0
    };
    this.skills.set(id, skill);
    return skill;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentMessageId++;
    const message: ContactMessage = { 
      ...insertMessage, 
      id,
      createdAt: new Date()
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values())
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getPortfolioInfo(): Promise<PortfolioInfo | undefined> {
    return this.portfolioInfo;
  }

  async updatePortfolioInfo(info: InsertPortfolioInfo): Promise<PortfolioInfo> {
    this.portfolioInfo = { 
      ...info, 
      id: 1,
      phone: info.phone ?? null,
      location: info.location ?? null,
      linkedinUrl: info.linkedinUrl ?? null,
      githubUrl: info.githubUrl ?? null,
      twitterUrl: info.twitterUrl ?? null,
      instagramUrl: info.instagramUrl ?? null,
      profileImage: info.profileImage ?? null,
      resumeUrl: info.resumeUrl ?? null
    };
    return this.portfolioInfo;
  }
}

export const storage = new MemStorage();
